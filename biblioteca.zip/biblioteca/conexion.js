const mongoose = require('mongoose')

const URI_BD = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/biblioteca'

async function conectarBD () {
  try {
    await mongoose.connect(URI_BD)
    console.log(`[BD] Conexión establecida con "${mongoose.connection.name}"`)
  } catch (error) {
    console.error('[BD] No fue posible conectar con MongoDB:', error.message)
    throw error
  }
}

// Permite probar la conexión sola: node conexion.js
if (require.main === module) {
  conectarBD()
    .then(() => mongoose.disconnect())
    .catch(() => process.exit(1))
}

module.exports = conectarBD
