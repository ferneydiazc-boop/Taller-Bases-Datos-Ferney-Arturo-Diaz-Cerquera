const express = require('express')
const rutasLibros = require('./routes/libro')

const app = express()

app.set('port', process.env.PORT || 3000)
app.use(express.json())

app.use('/api', rutasLibros)

// Ruta inexistente
app.use((req, res) => {
  res.status(404).json({ mensaje: 'Ruta no encontrada' })
})

// Errores generales (por ejemplo, un JSON mal formado)
app.use((err, req, res, next) => {
  const estado = err.status || 500
  res.status(estado).json({ mensaje: err.message || 'Error interno del servidor' })
})

module.exports = app
