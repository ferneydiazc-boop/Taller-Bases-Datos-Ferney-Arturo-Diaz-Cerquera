# Biblioteca - Conexión MongoDB

API REST para gestionar el catálogo de una biblioteca, construida con Node.js, Express y Mongoose.

## Requisitos
- Node.js 18 o superior
- MongoDB en ejecución (por defecto `localhost:27017`)

## Instalación y uso
    npm install
    npm start            # levanta la API en http://localhost:3000
    npm run conexion     # solo prueba la conexión a MongoDB

Variables opcionales (ver `.env.example`):
- `PORT`: puerto del servidor (3000 por defecto)
- `MONGODB_URI`: cadena de conexión (`mongodb://127.0.0.1:27017/biblioteca` por defecto)

## Estructura
    conexion.js        Conexión a MongoDB
    index.js           Arranque: conecta a la BD y levanta el servidor
    app.js             Configuración de Express
    models/libro.js    Esquema del libro
    controllers/       Lógica de cada operación
    routes/            Definición de endpoints

## Endpoints
| Método | Ruta              | Descripción                |
|--------|-------------------|----------------------------|
| GET    | /api/libros       | Lista libros (`?autor=` `?genero=`) |
| GET    | /api/libros/:id   | Consulta un libro          |
| POST   | /api/libros       | Registra un libro          |
| PUT    | /api/libros/:id   | Actualiza un libro         |
| DELETE | /api/libros/:id   | Elimina un libro           |

### Ejemplo de cuerpo (POST / PUT)
```json
{
  "titulo": "Cien años de soledad",
  "autor": "Gabriel García Márquez",
  "isbn": "978-0307474728",
  "genero": "Novela",
  "editorial": "Sudamericana",
  "anioPublicacion": 1967,
  "ejemplares": 3
}
```
