const mongoose = require('mongoose')

const esquemaLibro = new mongoose.Schema(
  {
    titulo: { type: String, required: [true, 'El título es obligatorio'], trim: true },
    autor: { type: String, required: [true, 'El autor es obligatorio'], trim: true },
    isbn: { type: String, trim: true, unique: true, sparse: true },
    genero: { type: String, trim: true },
    editorial: { type: String, trim: true },
    anioPublicacion: { type: Number, min: [0, 'El año no es válido'] },
    ejemplares: { type: Number, default: 1, min: [0, 'Los ejemplares no pueden ser negativos'] },
    prestado: { type: Boolean, default: false }
  },
  { timestamps: true }
)

module.exports = mongoose.model('Libro', esquemaLibro, 'libros')
