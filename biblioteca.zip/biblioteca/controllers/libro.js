const mongoose = require('mongoose')
const Libro = require('../models/libro')

const CAMPOS = ['titulo', 'autor', 'isbn', 'genero', 'editorial', 'anioPublicacion', 'ejemplares', 'prestado']

// Toma del cuerpo solo los campos permitidos
const filtrarCampos = (cuerpo = {}) =>
  CAMPOS.reduce((acc, campo) => {
    if (cuerpo[campo] !== undefined) acc[campo] = cuerpo[campo]
    return acc
  }, {})

const idInvalido = (id) => !mongoose.isValidObjectId(id)

// Escapa caracteres especiales para usar texto del usuario en una RegExp
const escapar = (texto) => String(texto).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

// Traduce errores de Mongoose a respuestas HTTP
function manejarError (res, error, accion) {
  if (error.name === 'ValidationError') {
    const detalle = Object.values(error.errors).map((e) => e.message)
    return res.status(400).json({ mensaje: 'Datos no válidos', detalle })
  }
  if (error.code === 11000) {
    return res.status(409).json({ mensaje: 'Ya existe un libro con ese ISBN' })
  }
  return res.status(500).json({ mensaje: `Error al ${accion}`, error: error.message })
}

const libroController = {
  async listarLibros (req, res) {
    try {
      const filtro = {}
      if (req.query.autor) filtro.autor = new RegExp(escapar(req.query.autor), 'i')
      if (req.query.genero) filtro.genero = new RegExp(escapar(req.query.genero), 'i')
      const libros = await Libro.find(filtro).sort({ titulo: 1 })
      res.status(200).json(libros)
    } catch (error) {
      manejarError(res, error, 'listar los libros')
    }
  },

  async obtenerLibro (req, res) {
    const { id } = req.params
    if (idInvalido(id)) return res.status(400).json({ mensaje: 'El id no es válido' })
    try {
      const libro = await Libro.findById(id)
      if (!libro) return res.status(404).json({ mensaje: 'Libro no encontrado' })
      res.status(200).json(libro)
    } catch (error) {
      manejarError(res, error, 'consultar el libro')
    }
  },

  async crearLibro (req, res) {
    try {
      const libro = await Libro.create(filtrarCampos(req.body))
      res.status(201).json({ libro })
    } catch (error) {
      manejarError(res, error, 'registrar el libro')
    }
  },

  async actualizarLibro (req, res) {
    const { id } = req.params
    if (idInvalido(id)) return res.status(400).json({ mensaje: 'El id no es válido' })
    try {
      const libro = await Libro.findByIdAndUpdate(id, filtrarCampos(req.body), {
        returnDocument: 'after',
        runValidators: true
      })
      if (!libro) return res.status(404).json({ mensaje: 'El libro no existe' })
      res.status(200).json({ libro })
    } catch (error) {
      manejarError(res, error, 'actualizar el libro')
    }
  },

  async eliminarLibro (req, res) {
    const { id } = req.params
    if (idInvalido(id)) return res.status(400).json({ mensaje: 'El id no es válido' })
    try {
      const libro = await Libro.findByIdAndDelete(id)
      if (!libro) return res.status(404).json({ mensaje: 'El libro no existe' })
      res.status(200).json({ mensaje: 'Libro eliminado', libro })
    } catch (error) {
      manejarError(res, error, 'eliminar el libro')
    }
  }
}

module.exports = libroController
