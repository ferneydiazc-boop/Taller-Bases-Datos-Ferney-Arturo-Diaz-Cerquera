const { Router } = require('express')
const libroController = require('../controllers/libro')

const router = Router()

router.get('/libros', libroController.listarLibros)
router.get('/libros/:id', libroController.obtenerLibro)
router.post('/libros', libroController.crearLibro)
router.put('/libros/:id', libroController.actualizarLibro)
router.delete('/libros/:id', libroController.eliminarLibro)

module.exports = router
