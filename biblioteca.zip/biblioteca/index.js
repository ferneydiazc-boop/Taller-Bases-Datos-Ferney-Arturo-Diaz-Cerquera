const conectarBD = require('./conexion')
const app = require('./app')

async function iniciar () {
  try {
    await conectarBD()
    const puerto = app.get('port')
    app.listen(puerto, () => {
      console.log(`[API] Biblioteca disponible en http://localhost:${puerto}/api/libros`)
    })
  } catch (error) {
    process.exit(1)
  }
}

iniciar()
